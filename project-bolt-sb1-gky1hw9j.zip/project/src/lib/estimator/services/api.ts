import type { SubmissionPayload, SubmissionResult } from '../types';
import { sendReport } from './EmailService';

export async function submitEstimate(payload: SubmissionPayload): Promise<SubmissionResult> {
  // Mock API: log the payload and invoke the email service.
  // eslint-disable-next-line no-console
  console.log('[api.submitEstimate] payload', {
    calculatorType: payload.calculatorType,
    projectTitle: payload.projectTitle,
    customerName: payload.customerName,
    customerEmail: payload.customerEmail,
    estimate: payload.estimate ? { low: payload.estimate.costRange.low, high: payload.estimate.costRange.high } : null,
    summary: payload.summary?.summary ?? null,
    fileCount: payload.files.length,
  });
  return sendReport(payload);
}
